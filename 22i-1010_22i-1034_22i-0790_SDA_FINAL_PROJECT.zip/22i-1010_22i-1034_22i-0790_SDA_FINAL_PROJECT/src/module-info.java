/**
 * 
 */
/**
 * 
 */
module SDA_FINAL_PROJECT {
    requires javafx.controls;
    requires javafx.fxml;
	requires java.sql;
    opens SDA_FINAL_PROJECT to javafx.graphics, javafx.fxml;
}
