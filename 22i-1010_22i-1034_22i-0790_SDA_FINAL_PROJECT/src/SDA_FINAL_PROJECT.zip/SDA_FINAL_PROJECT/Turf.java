package SDA_FINAL_PROJECT;
import java.util.Random;


public class Turf{
	int rating;
	boolean availability;
	String Name;
	
	Turf(String Name){
		Random random = new Random();
		rating=random.nextInt(5) + 1;
		this.availability=true;
		this.Name=Name;
	}
	public String getName(){
		return this.Name;
	}
}