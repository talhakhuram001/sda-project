package SDA_FINAL_PROJECT;
import java.util.List;
import java.util.ArrayList;


public class PlayerInterface{
	
	List<Player> players= new ArrayList<>();
	public class Main {
	    public static void main(String[] args) {
	        System.out.println("Hello, world!");
	    }
	}
	

	
}