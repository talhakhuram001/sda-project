package SDA_FINAL_PROJECT;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class MainMenu {
    private List<Turf> turfs = new ArrayList<>();
    private List<Player> players = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();
    private List<TurfOwner> turfOwners = new ArrayList<>();
    // Method to add a new turf (only accessible by TurfOwner or Admin)
    public void addTurf(Turf turf, TurfOwner user) {
        if (user instanceof TurfOwner ) {
            turfs.add(turf);
            user.turfs.add(turf);
            System.out.println("Turf added successfully.");
        } else {
            System.out.println("Permission denied: Only Turf Owners or Admins can add turfs.");
        }
    }

    // Method to remove a turf (only accessible by TurfOwner or Admin)
    public void removeTurf(Turf turf, TurfOwner user) {
        if (user instanceof TurfOwner ) {
            turfs.remove(turf);
            user.turfs.remove(turf);
            System.out.println("Turf removed successfully.");
        } else {
            System.out.println("Permission denied: Only Turf Owners or Admins can remove turfs.");
        }
    }

    public void bookTurf(Player player, Turf turf, User user) {
        if (user instanceof Player) {
            // Create a new booking for the player
            Booking newBooking = new Booking(player, turf);
            bookings.add(newBooking);
            System.out.println("Booking confirmed for player: " + player.getUsername() + " at " + turf.getName());
        } else {
            System.out.println("Permission denied: Only Players can book turfs.");
        }
    }

    public void viewBookingsForTurf(Turf turf, User user) {
        if (user instanceof TurfOwner ) {
            for (Booking booking : bookings) {
                if (booking.getTurf().equals(turf)) {
                    System.out.println("Booking for Player: " + booking.getPlayer().getUsername());
                }
            }
        } else {
            System.out.println("Permission denied: Only Turf Owners or Admins can view bookings for this turf.");
        }
    }

    public static void main(String[] args) {
        MainMenu manager = new MainMenu();

        // Create users
        Player player = new Player("player1", "password", "player1@example.com" ,manager.players.size()-1 );
        TurfOwner owner = new TurfOwner("owner1", "password", "owner1@example.com");

        // Add users to the system
        manager.players.add(player);
        manager.turfOwners.add(owner);
        

        Turf turf1 = new Turf("Turf1");
        manager.addTurf(turf1, owner);

        manager.bookTurf(player,turf1, owner);

    }
}