package SDA_FINAL_PROJECT;

public class Player extends User {
    private int ranking;
    public PlayerStats stats;
    public Player(String username, String password, String email, int ranking) {
        super(username, password, email, "Player");
        this.ranking = ranking; 
    }

    @Override
    public void performRole() {
        System.out.println("Player can book turfs, view their performance, and update their profile.");
    }

    @Override
    public void viewProfile() {
        System.out.println("Player Profile: " + getUsername() + ", Ranking: " + ranking);
    }
    

    

}
