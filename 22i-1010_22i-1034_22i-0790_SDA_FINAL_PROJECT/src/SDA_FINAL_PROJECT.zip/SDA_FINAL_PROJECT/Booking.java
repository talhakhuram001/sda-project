package SDA_FINAL_PROJECT;

public class Booking {
    private Player player; 
    private Turf turf;     

    public Booking(Player player, Turf turf) {
        this.player = player;
        this.turf = turf;
    }

    // Getter for player
    public Player getPlayer() {
        return player;
    }

    // Getter for turf
    public Turf getTurf() {
        return turf;
    }

}
